// src/components/SettingsPanel.jsx
import React, { useState, useEffect } from "react";
import { buildAndPersistProfileSummary } from "../utils/personalization";
import { auth } from "../utils/firebaseInit";
import {
  GoogleAuthProvider,
  signInWithPopup,
  signOut,
  onAuthStateChanged,
  signInAnonymously,
} from "firebase/auth";
import { LogIn, LogOut, UserCircle2, HelpCircle } from "lucide-react";

export default function SettingsPanel({ settings, setSettings, setCurrentView }) {
  const [form, setForm] = useState(
    settings || { aerythTone: "Companion (Friendly)", userInfo: "", routineCriteria: "" }
  );
  const [user, setUser] = useState(null);
  const [authStatus, setAuthStatus] = useState("Loading...");

  useEffect(() => {
    // Auto sign in anonymously if no user exists
    const unsub = onAuthStateChanged(auth, async (u) => {
      if (!u) {
        await signInAnonymously(auth);
      } else {
        setUser(u);
        setAuthStatus(u.isAnonymous ? "Anonymous" : u.displayName || u.email);
      }
    });
    return () => unsub();
  }, []);

  const handleGoogleSignIn = async () => {
    try {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
      window.location.reload();
    } catch (err) {
      console.error("Google sign-in error:", err);
      alert("Google sign-in failed. Check console for details.");
    }
  };

  const handleSignOut = async () => {
    try {
      await signOut(auth);
      await signInAnonymously(auth); // fallback to anonymous again
      window.location.reload();
    } catch (err) {
      console.error("Sign-out error:", err);
    }
  };

  const saveSettings = async () => {
    setSettings(form);
    await buildAndPersistProfileSummary({ settings: form, routines: [], diary: {} });
    setCurrentView("explore");
  };

  return (
    <div className="flex items-center justify-center h-full p-6 overflow-auto">
      <div className="max-w-2xl w-full mx-auto">
        <div className="bg-white p-6 rounded-xl shadow">
          <h2 className="text-2xl font-bold text-violet-700 mb-3">Aeryth Settings</h2>
          <div className="space-y-4">
            <div>
              <label className="font-semibold">Aeryth's Tone</label>
              <select
                value={form.aerythTone}
                onChange={(e) => setForm({ ...form, aerythTone: e.target.value })}
                className="w-full mt-1 p-3 border rounded-lg"
              >
                <option>Companion (Friendly)</option>
                <option>Analyst (Logical)</option>
                <option>Coach (Motivational)</option>
                <option>Sage (Wise)</option>
              </select>
            </div>

            <div>
              <label className="font-semibold">About You</label>
              <textarea
                value={form.userInfo}
                onChange={(e) => setForm({ ...form, userInfo: e.target.value })}
                className="w-full mt-1 p-3 border rounded-lg"
                rows={3}
              />
            </div>

            <div>
              <label className="font-semibold">Routine Criteria</label>
              <input
                value={form.routineCriteria}
                onChange={(e) => setForm({ ...form, routineCriteria: e.target.value })}
                className="w-full mt-1 p-3 border rounded-lg"
              />
            </div>

            {/* 🔐 Auth Section (replaces Location) */}
            <div>
              <label className="font-semibold flex items-center gap-1">
                Account
                <div className="relative group cursor-pointer">
                  <HelpCircle size={16} className="text-gray-400" />
                  <div className="absolute hidden group-hover:block top-6 left-0 bg-gray-700 text-white text-sm rounded p-2 w-64 z-10">
                    You start as Anonymous by default. Sign in with Google to sync your data across devices.
                  </div>
                </div>
              </label>

              <div className="flex items-center justify-between mt-2 p-3 border rounded-lg bg-gray-50">
                <div className="flex items-center gap-2">
                  <UserCircle2 className="text-violet-600" />
                  <span className="text-gray-700 font-medium">
                    {authStatus || "Not signed in"}
                  </span>
                </div>

                <div className="flex gap-2">
                  {user?.isAnonymous ? (
                    <button
                      onClick={handleGoogleSignIn}
                      className="flex items-center gap-1 px-3 py-1.5 rounded-full bg-violet-500 text-white font-semibold hover:bg-violet-600"
                    >
                      <LogIn size={16} /> Sign in with Google
                    </button>
                  ) : (
                    <button
                      onClick={handleSignOut}
                      className="flex items-center gap-1 px-3 py-1.5 rounded-full bg-red-500 text-white font-semibold hover:bg-red-600"
                    >
                      <LogOut size={16} /> Sign Out
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>

          <div className="flex gap-3 mt-6">
            <button
              onClick={saveSettings}
              className="bg-violet-500 text-white py-2 px-4 rounded font-bold"
            >
              Save
            </button>
            <button
              onClick={() => setForm(settings)}
              className="py-2 px-4 rounded border"
            >
              Reset
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
